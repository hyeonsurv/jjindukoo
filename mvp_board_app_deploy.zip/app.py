"""
Simple Flask-based MVP for a fandom-centric community platform.

This application demonstrates the core flow outlined in the business plan:

  • Users can sign up and log in.
  • After logging in, users select an interest category (e.g. 애니, 게임, K‑POP, 스포츠, 웹툰).
  • They must pass a short quiz on their chosen category to gain access to the corresponding
    discussion board. Quiz scores confer badges (입문/중수/고인물) based on performance.
  • Authenticated users with a badge can create posts on the board for that category and
    view posts from other users.

Data is stored in simple in‑memory dictionaries for demonstration purposes. In a production
environment you would replace these with persistent storage (e.g. a database). Session
information is stored using Flask’s session mechanism.

To run the application:
    python app.py

Then navigate to http://localhost:5000 in your browser.

Note: The secret key is hardcoded for demonstration; replace it with a secure random
value for any real deployment.
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.utils import secure_filename
import os
from datetime import datetime, timedelta
from random import sample

app = Flask(__name__)
# IMPORTANT: set a strong secret key for real applications
app.secret_key = "change_this_secret_key"

# Configure upload folder and allowed file extensions
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["UPLOAD_FOLDER"] = os.path.join(BASE_DIR, "static", "uploads")
# Create the upload folder if it does not exist
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Define which file extensions are permitted for upload
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "mp4", "mov", "webm"}


def allowed_file(filename: str) -> bool:
    """Return True if the file has an allowed extension."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# Define available categories and quiz questions. Each question has multiple choice options
# and a single correct answer. Feel free to expand or refine the questions.
quizzes = {
    "애니": [
        {
            "question": "만화 및 애니메이션 시리즈 '나루토'의 주인공 이름은 무엇입니까?",
            "options": ["루피", "은혼", "나루토", "공룡"],
            "answer": "나루토",
        },
        {
            "question": "'원피스'에서 루피가 찾으려는 전설의 보물 이름은 무엇입니까?",
            "options": ["포켓몬", "오로치", "트리플엑스", "원피스"],
            "answer": "원피스",
        },
        {
            "question": "'포켓몬'에서 피카츄의 타입은 무엇입니까?",
            "options": ["물", "불", "전기", "풀"],
            "answer": "전기",
        },
        {
            "question": "'명탐정 코난'에서 코난의 본명은?",
            "options": ["신이치", "미츠히코", "교코", "타카야"],
            "answer": "신이치",
        },
        {
            "question": "'드래곤볼'에서 손오공이 사용하는 대표적인 기술은 무엇입니까?",
            "options": ["사이클론", "귀도권", "카메하메하", "편지봉투"],
            "answer": "카메하메하",
        },
        {
            "question": "'귀멸의 칼날'의 주인공 이름은 무엇입니까?",
            "options": ["카가야", "탄지로", "젠이츠", "이노스케"],
            "answer": "탄지로",
        },
        {
            "question": "'진격의 거인'에서 거인을 연구하는 조사병단의 이름은?",
            "options": ["헌병단", "조사병단", "주둔병단", "군사교령단"],
            "answer": "조사병단",
        },
        {
            "question": "'센과 치히로의 행방불명'을 감독한 일본의 유명 애니메이션 감독은 누구입니까?",
            "options": ["미야자키 하야오", "신카이 마코토", "오토모 카츠히로", "콘 사토시"],
            "answer": "미야자키 하야오",
        },
        {
            "question": "'은혼'의 주인공 긴토키는 어떤 일을 하며 생계를 유지합니까?",
            "options": ["사무라이 도장 운영", "프리랜서(만능 해결사)", "경찰", "요리사"],
            "answer": "프리랜서(만능 해결사)",
        },
        {
            "question": "'이웃집 토토로'에 나오는 숲의 영혼의 이름은?",
            "options": ["모노노케", "토토로", "네코버스", "하쿠"],
            "answer": "토토로",
        },
    ],
    "게임": [
        {
            "question": "대한민국에서 제작된 MMORPG 게임 중 하나인 '리니지'를 만든 회사는?",
            "options": ["블리자드", "넥슨", "엔씨소프트", "스마일게이트"],
            "answer": "엔씨소프트",
        },
        {
            "question": "'LOL'로 알려진 인기 게임의 정식 명칭은 무엇입니까?",
            "options": ["리그 오브 레전드", "라스트 오브 어스", "리치 오어 리치", "라이프 오브 랜덤"],
            "answer": "리그 오브 레전드",
        },
        {
            "question": "'마인크래프트'의 주된 게임 요소는?",
            "options": ["퍼즐", "건설 및 생존", "레이싱", "카드배틀"],
            "answer": "건설 및 생존",
        },
        {
            "question": "'오버워치'에서 트레이서는 어떤 능력을 가지고 있습니까?",
            "options": ["시간을 조종한다", "하늘을 난다", "투명해진다", "변신한다"],
            "answer": "시간을 조종한다",
        },
        {
            "question": "닌텐도의 마스코트 캐릭터 마리오가 처음으로 등장한 게임은?",
            "options": ["슈퍼 마리오 브라더스", "동키콩", "젤다의 전설", "포켓몬"] ,
            "answer": "동키콩",
        },
        {
            "question": "FPS 게임 '배틀그라운드'를 개발한 회사는?",
            "options": ["블루홀", "라이엇게임즈", "EA", "유비소프트"],
            "answer": "블루홀",
        },
        {
            "question": "닌텐도 스위치 출시 연도는?",
            "options": ["2015년", "2016년", "2017년", "2018년"],
            "answer": "2017년",
        },
        {
            "question": "게임 '스타크래프트'에서 인간 종족의 이름은?",
            "options": ["프로토스", "저그", "테란", "마린"],
            "answer": "테란",
        },
        {
            "question": "모바일 게임 '클래시 로얄'을 만든 회사는?",
            "options": ["슈퍼셀", "텐센트", "블리자드", "넷이즈"],
            "answer": "슈퍼셀",
        },
        {
            "question": "'레드 데드 리뎀션 2'의 배경이 되는 시대는?",
            "options": ["서부 개척 시대", "1차 세계대전", "2차 세계대전", "현대"],
            "answer": "서부 개척 시대",
        },
    ],
    "K‑POP": [
        {
            "question": "방탄소년단(BTS)의 팬클럽 명칭은 무엇입니까?",
            "options": ["아이돌", "아미", "팬덤", "스위트"],
            "answer": "아미",
        },
        {
            "question": "블랙핑크의 멤버가 아닌 사람은 누구입니까?",
            "options": ["지수", "제니", "마크", "리사"],
            "answer": "마크",
        },
        {
            "question": "EXO의 데뷔곡은 무엇입니까?",
            "options": ["으르렁", "중독", "MAMA", "LOVE SHOT"],
            "answer": "MAMA",
        },
        {
            "question": "트와이스 멤버 중 일본인 멤버는 몇 명입니까?",
            "options": ["1명", "2명", "3명", "4명"],
            "answer": "3명",
        },
        {
            "question": "빅뱅의 리더는 누구입니까?",
            "options": ["탑", "대성", "태양", "지드래곤"],
            "answer": "지드래곤",
        },
        {
            "question": "아이유의 본명은 무엇입니까?",
            "options": ["이지은", "김지민", "최지혜", "박지은"],
            "answer": "이지은",
        },
        {
            "question": "NCT의 유닛이 아닌 것은?",
            "options": ["NCT 127", "NCT U", "NCT Dream", "NCT H"],
            "answer": "NCT H",
        },
        {
            "question": "걸그룹 ITZY의 데뷔곡은?",
            "options": ["달라달라", "ICY", "WANNABE", "LOCO"],
            "answer": "달라달라",
        },
        {
            "question": "SEVENTEEN은 몇 명의 멤버로 구성되어 있습니까?",
            "options": ["13명", "15명", "17명", "12명"],
            "answer": "13명",
        },
        {
            "question": "원더걸스의 히트곡 'Nobody'는 어느 해에 발표되었나요?",
            "options": ["2007년", "2008년", "2009년", "2010년"],
            "answer": "2008년",
        },
    ],
    "스포츠": [
        {
            "question": "2022년 카타르 월드컵에서 우승한 국가는?",
            "options": ["프랑스", "브라질", "아르헨티나", "독일"],
            "answer": "아르헨티나",
        },
        {
            "question": "올림픽에서 매 4년마다 개최되는 하계종목과 동계종목의 구분은 언제부터 도입되었습니까?",
            "options": ["1924년", "1948년", "1960년", "1992년"],
            "answer": "1992년",
        },
        {
            "question": "NBA에서 역대 최다 우승팀은 어느 팀입니까?",
            "options": ["LA 레이커스", "보스턴 셀틱스", "시카고 불스", "골든스테이트 워리어스"],
            "answer": "보스턴 셀틱스",
        },
        {
            "question": "한국 프로야구(KBO) 리그의 창립 연도는 언제입니까?",
            "options": ["1980년", "1982년", "1985년", "1990년"],
            "answer": "1982년",
        },
        {
            "question": "테니스 그랜드슬램 대회가 아닌 것은?",
            "options": ["윔블던", "US 오픈", "프랑스 오픈", "파리 마스터스"],
            "answer": "파리 마스터스",
        },
        {
            "question": "세계적으로 가장 많이 시청되는 스포츠 이벤트는?",
            "options": ["올림픽", "슈퍼볼", "월드컵", "F1"],
            "answer": "월드컵",
        },
        {
            "question": "메이저 리그 야구(MLB)에서 유명한 'Babe Ruth'의 팀이 아닌 것은?",
            "options": ["보스턴 레드삭스", "뉴욕 양키스", "뉴욕 메츠", "애틀랜타 브레이브스"],
            "answer": "뉴욕 메츠",
        },
        {
            "question": "테니스의 4대 그랜드슬램이 아닌 대회는?",
            "options": ["호주 오픈", "윔블던", "프랑스 오픈", "로마 오픈"],
            "answer": "로마 오픈",
        },
        {
            "question": "NBA 슈퍼스타 르브론 제임스가 최초로 우승한 팀은?",
            "options": ["클리블랜드 캐벌리어스", "마이애미 히트", "LA 레이커스", "보스턴 셀틱스"],
            "answer": "마이애미 히트",
        },
        {
            "question": "100m 세계신기록을 보유하고 있는 선수는?",
            "options": ["우사인 볼트", "타이슨 게이", "저스틴 게틀린", "요한 블레이크"],
            "answer": "우사인 볼트",
        },
    ],
    "웹툰": [
        {
            "question": "웹툰 '마음의 소리'의 작가는 누구입니까?",
            "options": ["조석", "이말년", "주호민", "김풍"],
            "answer": "조석",
        },
        {
            "question": "'신과 함께' 웹툰의 주요 내용은 무엇입니까?",
            "options": ["우주 탐험", "지옥 재판", "스포츠 대회", "음악 경연"],
            "answer": "지옥 재판",
        },
        {
            "question": "웹툰 '유미의 세포들'에서 세포들이 상징하는 것은?",
            "options": ["음식물", "감정과 생각", "동물", "시간"],
            "answer": "감정과 생각",
        },
        {
            "question": "'나 혼자만 레벨업'은 어떤 장르의 웹툰입니까?",
            "options": ["스포츠", "학교 코미디", "판타지 액션", "로맨스"],
            "answer": "판타지 액션",
        },
        {
            "question": "웹툰 플랫폼 중 하나인 '레진코믹스'는 어느 나라 기업입니까?",
            "options": ["미국", "일본", "한국", "중국"],
            "answer": "한국",
        },
        {
            "question": "웹툰 '유미의 세포들' 작가는 누구입니까?",
            "options": ["이동건", "이나래", "주호민", "조석"],
            "answer": "이나래",
        },
        {
            "question": "웹툰 '미생'의 직장 배경은 어느 업종입니까?",
            "options": ["무역회사", "IT 회사", "출판사", "게임사"],
            "answer": "무역회사",
        },
        {
            "question": "'전지적 독자 시점'의 주인공 이름은?",
            "options": ["김독자", "한소영", "유승호", "이수빈"],
            "answer": "김독자",
        },
        {
            "question": "웹툰 '고수'의 주된 장르는 무엇입니까?",
            "options": ["무협 액션", "로맨스 코미디", "스포츠", "공포 스릴러"],
            "answer": "무협 액션",
        },
        {
            "question": "네이버 웹툰 '신의 탑'에서 주인공 '밤'이 올라가려는 것은?",
            "options": ["하늘", "탑", "바다", "지하"],
            "answer": "탑",
        },
    ],
}

# ---------------------------------------------------------------------------
# Additional quiz questions for each category.  To keep the quiz fresh, each
# category is expanded to include roughly 50 questions.  When a user takes a
# quiz, only 5 questions are drawn at random from the full set.  Feel free to
# adjust or expand these lists; ensure each question contains exactly one
# correct answer within the options list.
more_questions = {
    "애니": [
        {"question": "스튜디오 지브리에서 제작한 애니메이션 영화가 아닌 것은?", "options": ["이웃집 토토로", "센과 치히로의 행방불명", "원피스", "하울의 움직이는 성"], "answer": "원피스"},
        {"question": "'날씨의 아이'와 '너의 이름은'을 감독한 사람은?", "options": ["미야자키 하야오", "신카이 마코토", "오토모 카츠히로", "모리타 히로유키"], "answer": "신카이 마코토"},
        {"question": "'사자에상'은 어떤 장르의 애니메이션입니까?", "options": ["일상 코미디", "SF", "공포", "스포츠"], "answer": "일상 코미디"},
        {"question": "애니메이션 '코드 기어스'의 주인공 루루슈가 사용하는 능력은?", "options": ["금단의 마법", "기어스", "악마의 눈", "백귀"], "answer": "기어스"},
        {"question": "'원펀맨'에서 사이타마의 별명은?", "options": ["머리없는 기사", "원펀맨", "사이보그맨", "괴물 헌터"], "answer": "원펀맨"},
        {"question": "'하이큐!!'는 어떤 스포츠를 소재로 한 애니메이션입니까?", "options": ["농구", "축구", "배구", "야구"], "answer": "배구"},
        {"question": "'나의 히어로 아카데미아'에서 주인공 미도리야 이즈쿠의 히어로 이름은?", "options": ["데쿠", "카차", "쇼토", "울트라맨"], "answer": "데쿠"},
        {"question": "'데스노트'에서 사신 리유크가 사람 세계에 떨어뜨린 물건은?", "options": ["사신의 검", "사신의 사과", "데스노트", "생명수"], "answer": "데스노트"},
        {"question": "'강철의 연금술사'에서 에드워드 엘릭이 잃은 신체 부위는?", "options": ["왼팔과 오른다리", "오른팔과 왼다리", "양다리", "왼팔과 오른눈"], "answer": "오른팔과 왼다리"},
        {"question": "'식극의 소마'에서 주인공 소마가 다니는 학교는?", "options": ["토츠키 요리학교", "호시노 학교", "카마도 요리학교", "쿠로코 요리학교"], "answer": "토츠키 요리학교"},
        {"question": "'마법소녀 마도카☆마기카'에서 소원을 들어주는 존재의 이름은?", "options": ["큐베", "모모", "치카", "마법사"], "answer": "큐베"},
        {"question": "'유유백서'에서 주인공 유스케가 사후에 수행하는 직업은?", "options": ["영계탐정", "사신", "마법사", "형사"], "answer": "영계탐정"},
        {"question": "'클라나드'의 주된 장르는?", "options": ["판타지", "일상 드라마", "스릴러", "스포츠"], "answer": "일상 드라마"},
        {"question": "'드라라라!!'의 배경이 되는 도시는?", "options": ["도쿄 이케부쿠로", "오사카", "교토", "삿포로"], "answer": "도쿄 이케부쿠로"},
        {"question": "'기동전사 건담' 시리즈에서 우주세기 연도가 시작되는 연대는?", "options": ["UC 0001", "UC 0079", "UC 0123", "UC 0205"], "answer": "UC 0079"},
        {"question": "'세일러문'의 주인공 우사기는 어떤 행성의 힘을 가지고 있습니까?", "options": ["화성", "금성", "달", "목성"], "answer": "달"},
        {"question": "'은하철도999'에서 천년여왕 메텔과 함께 여행하는 소년의 이름은?", "options": ["츠보라", "데쓰카", "테츠로", "다이스케"], "answer": "테츠로"},
        {"question": "'피구왕 통키'의 주인공 통키가 사용하는 필살기는?", "options": ["태풍슛", "타이거슛", "불꽃슛", "사자슛"], "answer": "태풍슛"},
        {"question": "'스즈미야 하루히의 우울'에서 SOS 단을 결성한 주인공의 이름은?", "options": ["스즈미야 하루히", "키온", "나가토 유키", "아사히나 미쿠루"], "answer": "스즈미야 하루히"},
        {"question": "'마크로스' 시리즈의 상징적인 전투기는?", "options": ["발키리", "제노사이드", "엑시아", "에반게리온"], "answer": "발키리"},
        {"question": "'케로로 중사'에서 케로로는 어느 행성 출신입니까?", "options": ["화성", "케론성", "지구", "명왕성"], "answer": "케론성"},
        {"question": "'블리치'의 주인공 이치고의 직업은?", "options": ["사신", "닌자", "요괴", "소년"], "answer": "사신"},
        {"question": "'하울의 움직이는 성'에서 소피가 저주로 변한 것은?", "options": ["노인", "개구리", "호랑이", "고양이"], "answer": "노인"},
        {"question": "'슬램덩크'에서 강백호가 속한 고등학교 농구 팀 이름은?", "options": ["북산", "능남", "해남", "상양"], "answer": "북산"},
        {"question": "'달빛천사'에서 미스티체리아의 정체는?", "options": ["천사", "악마", "가수", "마법사"], "answer": "천사"},
        {"question": "'문호 스트레이 독스'에서 아츠시의 변신 능력은?", "options": ["호랑이", "늑대", "사자", "고양이"], "answer": "호랑이"},
        {"question": "'주술회전'에서 이타도리 유우지가 몸에 봉인한 저주 이름은?", "options": ["스쿠나", "쿠나츠", "무라카미", "오로치"], "answer": "스쿠나"},
        {"question": "'프리큐어' 시리즈의 첫 번째 작품은?", "options": ["후레시 프리큐어", "두근두근 프리큐어", "빛의 전사 프리큐어", "스마일 프리큐어"], "answer": "빛의 전사 프리큐어"},
        {"question": "'히로아카'에서 폭발 개성을 가진 캐릭터는?", "options": ["토도로키 쇼토", "바쿠고 카츠키", "우라라카 오챠코", "이이다 텐야"], "answer": "바쿠고 카츠키"},
        {"question": "'유희왕'에서 주인공 유우기가 사용하는 카드 게임의 이름은?", "options": ["듀얼몬스터즈", "포켓몬 카드", "배틀로얄", "마법카드"], "answer": "듀얼몬스터즈"},
        {"question": "'핑퐁'은 어떤 스포츠를 다룬 애니메이션입니까?", "options": ["배드민턴", "탁구", "테니스", "수영"], "answer": "탁구"},
        {"question": "'원아웃'은 어떤 스포츠를 소재로 한 작품입니까?", "options": ["야구", "축구", "농구", "배구"], "answer": "야구"},
        {"question": "'죠죠의 기묘한 모험'에서 나오는 초자연적 능력은?", "options": ["스탠드", "퀴르케", "하마온", "체라"], "answer": "스탠드"},
        {"question": "'다이아몬드 에이스'의 주인공 사와무라 에이준의 포지션은?", "options": ["포수", "1루수", "투수", "유격수"], "answer": "투수"},
        {"question": "'건담 SEED'에서 아스란의 기체 이름은?", "options": ["프리덤", "저스티스", "스트라이크", "데스티니"], "answer": "저스티스"},
        {"question": "'몬스터'의 작가 우라사와 나오키의 다른 작품이 아닌 것은?", "options": ["20세기 소년", "플루토", "나루토", "마스터 키튼"], "answer": "나루토"},
        {"question": "'디지몬 어드벤처'에서 주인공이 처음 만난 파트너 디지몬은?", "options": ["아구몬", "가브몬", "파타몬", "피요몬"], "answer": "아구몬"},
        {"question": "'헌터×헌터'에서 곤 프릭스의 아버지 이름은?", "options": ["진 프릭스", "키르아 조르딕", "라이트", "실바"], "answer": "진 프릭스"},
        {"question": "'은수저'는 어떤 학교를 배경으로 합니까?", "options": ["농업 고등학교", "요리 학교", "음악 학교", "마술 학교"], "answer": "농업 고등학교"},
        {"question": "'드래곤 퀘스트: 다이의 대모험'의 주인공 이름은?", "options": ["다이", "크로코다인", "포프", "레오나"], "answer": "다이"},
    ],
    "게임": [
        {"question": "닌텐도에서 개발한 전용 게임 기기로 가장 오래된 것은?", "options": ["닌텐도 스위치", "게임보이", "Wii U", "닌텐도 DS"], "answer": "게임보이"},
        {"question": "액션 RPG 게임 '젤다의 전설: 브레스 오브 더 와일드'의 주인공 이름은?", "options": ["링크", "젤다", "가논", "임파"], "answer": "링크"},
        {"question": "모바일 게임 '앙상블 스타즈!'의 장르는?", "options": ["퍼즐", "리듬", "RPG", "스포츠"], "answer": "리듬"},
        {"question": "'콜 오브 듀티' 시리즈를 발행하는 회사는?", "options": ["유비소프트", "액티비전", "EA", "스퀘어에닉스"], "answer": "액티비전"},
        {"question": "'포트나이트'를 개발한 회사는?", "options": ["에픽게임즈", "벨브", "블리자드", "넥슨"], "answer": "에픽게임즈"},
        {"question": "'암살자의 신조(Assassin's Creed)' 시리즈는 어떤 시대를 배경으로 하지 않습니까?", "options": ["르네상스 이탈리아", "고대 그리스", "19세기 런던", "미래 도시"], "answer": "미래 도시"},
        {"question": "'스타듀 밸리'에서 주로 하는 활동은?", "options": ["농장 경영", "우주 탐사", "대도시 건설", "음악 제작"], "answer": "농장 경영"},
        {"question": "'동물의 숲'에서 사용되는 화폐 단위는?", "options": ["길", "벨", "루피", "골드"], "answer": "벨"},
        {"question": "'배틀그라운드'에서 마지막까지 살아남아 우승하는 것을 무엇이라고 부르나요?", "options": ["치킨", "라스트맨", "승리", "왕"], "answer": "치킨"},
        {"question": "'리그 오브 레전드'에서 네 마리의 드래곤 중 하나가 아닌 것은?", "options": ["바람 드래곤", "불 드래곤", "얼음 드래곤", "대지 드래곤"], "answer": "얼음 드래곤"},
        {"question": "'마리오 카트' 시리즈에서 아이템 박스에서 나오지 않는 것은?", "options": ["바나나", "파워스타", "블루쉘", "레드 코인"], "answer": "레드 코인"},
        {"question": "'디아블로' 시리즈의 주요 장르는?", "options": ["퍼즐", "액션 RPG", "스포츠", "음악"], "answer": "액션 RPG"},
        {"question": "'포켓몬스터'에서 시작하기 전에 선택할 수 없는 스타터 포켓몬 타입은?", "options": ["불", "물", "풀", "얼음"], "answer": "얼음"},
        {"question": "'철권' 시리즈에서 헤이하치 미시마의 싸움 스타일은?", "options": ["태권도", "가라테", "가정용 무술", "유도"], "answer": "가라테"},
        {"question": "'갓 오브 워'의 주인공 이름은?", "options": ["크레이토스", "제로스", "아레스", "제우스"], "answer": "크레이토스"},
        {"question": "'마인크래프트'에서 엔더드래곤을 물리치기 위해 방문하는 차원은?", "options": ["네더", "엔드", "오버월드", "에테르"], "answer": "엔드"},
        {"question": "일본의 유명 게임 제작사 스퀘어에닉스가 아닌 작품은?", "options": ["파이널 판타지", "드래곤 퀘스트", "킹덤 하츠", "젤다의 전설"], "answer": "젤다의 전설"},
        {"question": "'언차티드' 시리즈의 주인공이 찾는 것은?", "options": ["고대 유물", "공룡", "우주선", "보물지도"], "answer": "고대 유물"},
        {"question": "'러브라이브! 스쿨 아이돌 프로젝트'는 어떤 형태의 게임으로도 출시되었나요?", "options": ["리듬 게임", "슈팅 게임", "격투 게임", "퍼즐 게임"], "answer": "리듬 게임"},
        {"question": "'오버워치'에서 '정크랫'의 궁극기 이름은?", "options": ["죽이는 타이어", "폭주 기관총", "블레이드 스톰", "소리 방벽"], "answer": "죽이는 타이어"},
        {"question": "'파이널 판타지 VII'의 주인공 클라우드의 무기 이름은?", "options": ["건블레이드", "마스터소드", "브로드 소드", "바스터 소드"], "answer": "바스터 소드"},
        {"question": "'바이오하자드(Resident Evil)' 시리즈에서 좀비 사태를 일으킨 기업은?", "options": ["엄브렐라", "트라이포스", "신라컴퍼니", "세팔라"], "answer": "엄브렐라"},
        {"question": "'하프라이프'에서 주인공 고든 프리맨의 직업은?", "options": ["물리학자", "군인", "파일럿", "의사"], "answer": "물리학자"},
        {"question": "'GTA V'에서 등장하지 않는 주인공은?", "options": ["마이클", "프랭클린", "트레버", "CJ"], "answer": "CJ"},
        {"question": "'스플래툰' 시리즈의 캐릭터들은 어느 생물을 모티브로 합니까?", "options": ["오징어", "문어", "상어", "고래"], "answer": "오징어"},
        {"question": "'킹 오브 파이터즈(KOF)' 시리즈의 개발사는?", "options": ["SNK", "캡콤", "나미코", "세가"], "answer": "SNK"},
        {"question": "'테트리스'의 개발자는 어느 나라 출신입니까?", "options": ["일본", "러시아", "미국", "독일"], "answer": "러시아"},
        {"question": "'이블 위딘'의 감독 신지 미카미는 예전에 어느 게임을 감독했습니까?", "options": ["바이오하자드", "데빌 메이 크라이", "사일런트 힐", "테켄"], "answer": "바이오하자드"},
        {"question": "'저니(Journey)'를 개발한 회사는?", "options": ["댓게임컴퍼니", "나티독", "밸브", "파라소프트"], "answer": "댓게임컴퍼니"},
        {"question": "'사이렌' 시리즈는 어떤 장르의 게임입니까?", "options": ["호러 어드벤처", "스포츠", "레이싱", "리듬"], "answer": "호러 어드벤처"},
        {"question": "'붕괴3rd'를 개발한 중국 회사는?", "options": ["호요버스", "텐센트", "넷이즈", "퍼펙트월드"], "answer": "호요버스"},
        {"question": "'파이어 엠블렘' 시리즈에서 등장하는 무기 삼각 시스템에 없는 무기는?", "options": ["검", "창", "도끼", "총"], "answer": "총"},
        {"question": "'스카이림'은 '엘더스크롤' 시리즈 몇 번째 주요 작품입니까?", "options": ["3", "4", "5", "6"], "answer": "5"},
        {"question": "'리듬게임 '태고의 달인'에서 사용하는 악기 이름은?", "options": ["드럼", "기타", "피아노", "바이올린"], "answer": "드럼"},
        {"question": "'포탈' 시리즈에서 '케이크는 거짓말이다'라는 명대사를 한 AI는?", "options": ["GLaDOS", "Wheatley", "Cave Johnson", "Atlas"], "answer": "GLaDOS"},
        {"question": "'플라워(Flower)' 게임은 어떤 장르입니까?", "options": ["힐링 어드벤처", "호러 FPS", "퍼즐 RPG", "리듬"], "answer": "힐링 어드벤처"},
        {"question": "'리그 오브 레전드' e스포츠 리그가 아닌 것은?", "options": ["LCK", "LCS", "LEC", "WCS"], "answer": "WCS"},
        {"question": "'워프레임'에서 사용되는 장비가 아닌 것은?", "options": ["프레임", "프라이머리", "모듈", "볼트"], "answer": "모듈"},
        {"question": "'스팀' 플랫폼을 서비스하는 회사는?", "options": ["Valve", "Epic Games", "EA", "Ubisoft"], "answer": "Valve"},
        {"question": "'포켓몬스터'의 전설 포켓몬 중 하나가 아닌 것은?", "options": ["뮤", "뮤츠", "리아루", "루기아"], "answer": "리아루"},
    ],
    "K‑POP": [
        {"question": "방탄소년단(BTS)이 데뷔한 연도는?", "options": ["2011년", "2013년", "2015년", "2017년"], "answer": "2013년"},
        {"question": "블랙핑크 멤버 로제의 출신 국가는?", "options": ["한국", "뉴질랜드", "호주", "태국"], "answer": "뉴질랜드"},
        {"question": "세븐틴(SVT) 그룹 이름이 의미하는 것은 몇 명의 멤버를 뜻합니까?", "options": ["13명", "15명", "17명", "18명"], "answer": "13명"},
        {"question": "모모랜드의 히트곡 '뿜뿜'의 발매 연도는?", "options": ["2015년", "2018년", "2019년", "2017년"], "answer": "2018년"},
        {"question": "걸그룹 ITZY의 멤버가 아닌 사람은?", "options": ["예지", "리아", "유나", "지효"], "answer": "지효"},
        {"question": "걸그룹 NEWJEANS의 데뷔곡은?", "options": ["Attention", "Hype Boy", "Cookie", "OMG"], "answer": "Attention"},
        {"question": "SM엔터테인먼트 소속이 아닌 아티스트는?", "options": ["슈퍼주니어", "소녀시대", "트와이스", "샤이니"], "answer": "트와이스"},
        {"question": "EXO 멤버 중 중국 국적을 가진 멤버는?", "options": ["레이", "수호", "찬열", "디오"], "answer": "레이"},
        {"question": "NCT의 유닛으로 존재하지 않는 것은?", "options": ["NCT 127", "NCT Dream", "NCT 2018", "WayV"], "answer": "NCT 2018"},
        {"question": "오마이걸(OH MY GIRL)의 데뷔 소속사는?", "options": ["JYP 엔터테인먼트", "WM 엔터테인먼트", "YG 엔터테인먼트", "큐브 엔터테인먼트"], "answer": "WM 엔터테인먼트"},
        {"question": "2NE1의 데뷔곡은 무엇입니까?", "options": ["I AM THE BEST", "FIRE", "UGLY", "LONELY"], "answer": "FIRE"},
        {"question": "1세대 아이돌 그룹이 아닌 것은?", "options": ["H.O.T", "S.E.S", "젝스키스", "스트레이키즈"], "answer": "스트레이키즈"},
        {"question": "케이윌의 유명 곡 중 하나는?", "options": ["러브 119", "사랑했었다", "나 vs 너", "커피"], "answer": "사랑했었다"},
        {"question": "아이즈원 (IZ*ONE)의 활동 기간은 몇 년입니까?", "options": ["1년", "2년", "3년", "5년"], "answer": "2년"},
        {"question": "레드벨벳 멤버 중 리더는 누구입니까?", "options": ["아이린", "슬기", "웬디", "예리"], "answer": "아이린"},
        {"question": "TWICE 멤버 나연의 포지션은?", "options": ["메인보컬", "리드보컬", "메인댄서", "막내"], "answer": "리드보컬"},
        {"question": "우주소녀(WJSN)의 유닛 이름이 아닌 것은?", "options": ["쪼꼬미", "더 블랙", "NNR", "우아"], "answer": "NNR"},
        {"question": "2009년 데뷔한 걸그룹 중 하나는?", "options": ["카라", "소녀시대", "에이핑크", "티아라"], "answer": "티아라"},
        {"question": "빅스(VIXX)의 컨셉 장르로 유명한 것은?", "options": ["판타지", "호러", "스포츠", "로맨스"], "answer": "판타지"},
        {"question": "방탄소년단의 리더 RM의 본명은?", "options": ["김남준", "김석진", "민윤기", "정호석"], "answer": "김남준"},
        {"question": "이달의 소녀(LOONA)가 추구하는 세계관의 이름은?", "options": ["이달소 세계관", "블록베리", "이달의달", "Loonaverse"], "answer": "Loonaverse"},
        {"question": "위너(WINNER)의 데뷔 오디션 프로그램 이름은?", "options": ["Show Me The Money", "K-Pop Star", "WIN: Who is Next", "Superstar K"], "answer": "WIN: Who is Next"},
        {"question": "마마무의 데뷔곡은?", "options": ["Mr.애매모호", "음오아예", "넌 is 뭔들", "음악"], "answer": "Mr.애매모호"},
        {"question": "카리나, 윈터가 속한 걸그룹은?", "options": ["에스파", "있지", "뉴진스", "르세라핌"], "answer": "에스파"},
        {"question": "스트레이 키즈(Stray Kids)의 제작과 트레이닝을 담당한 JYP 프로듀서 이름은?", "options": ["JYP", "박진영", "비", "김종진"], "answer": "박진영"},
        {"question": "빅뱅 멤버 중 막내는 누구입니까?", "options": ["탑", "승리", "태양", "대성"], "answer": "승리"},
        {"question": "카라의 히트곡이 아닌 것은?", "options": ["미스터", "루팡", "판도라", "피카부"], "answer": "피카부"},
        {"question": "Mnet 오디션 프로그램 '프로듀스 101'에서 탄생한 프로젝트 그룹이 아닌 것은?", "options": ["아이오아이", "워너원", "아스트로", "아이즈원"], "answer": "아스트로"},
        {"question": "뉴이스트(NU'EST)는 어떤 회사 소속입니까?", "options": ["SM", "YG", "플레디스", "큐브"], "answer": "플레디스"},
        {"question": "소녀시대의 데뷔곡은?", "options": ["다시 만난 세계", "Gee", "소원을 말해봐", "Lion Heart"], "answer": "다시 만난 세계"},
        {"question": "트와이스(TWICE)의 일본인 멤버가 아닌 사람은?", "options": ["모모", "사나", "미나", "채영"], "answer": "채영"},
        {"question": "아이유의 히트곡이 아닌 것은?", "options": ["좋은 날", "밤편지", "팔레트", "하나만 더"], "answer": "하나만 더"},
        {"question": "EXO의 유닛이 아닌 것은?", "options": ["EXO-K", "EXO-L", "EXO-M", "EXO-CBX"], "answer": "EXO-L"},
        {"question": "BTOB의 메인보컬인 멤버는?", "options": ["서은광", "이민혁", "임현식", "프니엘"], "answer": "서은광"},
        {"question": "비투비(BTOB)의 데뷔 연도는?", "options": ["2010년", "2012년", "2014년", "2016년"], "answer": "2012년"},
        {"question": "엑소(EXO)의 팬덤 이름은?", "options": ["아미", "엑소엘", "원스", "리블링"], "answer": "엑소엘"},
        {"question": "샤이니(SHINee)의 멤버 중 솔로 앨범 'Move'를 낸 멤버는?", "options": ["온유", "키", "태민", "민호"], "answer": "태민"},
        {"question": "마마무(MAMAMOO)의 멤버가 아닌 사람은?", "options": ["문별", "솔라", "휘인", "수지"], "answer": "수지"},
        {"question": "TWICE의 팬덤 이름은?", "options": ["Once", "Twink", "Blink", "Buddy"], "answer": "Once"},
        {"question": "LE SSERAFIM의 리더는 누구입니까?", "options": ["채원", "사쿠라", "김혜원", "카즈하"], "answer": "채원"},
    ],
    "스포츠": [
        {"question": "축구 경기의 전반과 후반은 각각 몇 분입니까?", "options": ["30분", "45분", "50분", "60분"], "answer": "45분"},
        {"question": "'마라톤'이라는 단어는 어떤 전쟁에서 유래한 지명에서 비롯되었나요?", "options": ["페르시아 전쟁", "마라톤 전투", "트로이 전쟁", "스파르타 전쟁"], "answer": "마라톤 전투"},
        {"question": "농구 경기에서 3점 라인은 몇 미터입니까? (국제 규격)", "options": ["6.25m", "6.75m", "7.25m", "7.75m"], "answer": "6.75m"},
        {"question": "야구에서 '사이클링 히트'란?", "options": ["한 경기에 홈런만 3개", "단타, 2루타, 3루타, 홈런을 모두 치는 것", "무사 3루 상황", "투수가 삼진 10개"], "answer": "단타, 2루타, 3루타, 홈런을 모두 치는 것"},
        {"question": "골프에서 '버디'는 파보다 몇 타 적게 친 경우입니까?", "options": ["1타", "2타", "3타", "4타"], "answer": "1타"},
        {"question": "테니스에서 '랠리'는 무엇을 의미합니까?", "options": ["연속 서브", "연속 랠리 횟수", "공을 주고받는 교환", "이중 범실"], "answer": "공을 주고받는 교환"},
        {"question": "스피드 스케이팅에서 선수들이 한 바퀴 도는 링크 길이는 얼마입니까?", "options": ["250m", "333.3m", "400m", "500m"], "answer": "400m"},
        {"question": "미식축구 NFL 결승전을 일컫는 명칭은?", "options": ["월드 시리즈", "슈퍼볼", "파이널컵", "챔피언스컵"], "answer": "슈퍼볼"},
        {"question": "F1 그랑프리에서 연간 시즌 챔피언에게 주는 타이틀은?", "options": ["월드 서킷", "월드 챔피언", "월드 드라이버 챔피언십", "월드 컨스트럭터"], "answer": "월드 드라이버 챔피언십"},
        {"question": "유도에서 상대를 메치는 기술로, 한 손으로 상대의 팔을 잡아 넘기는 기술은?", "options": ["씨름", "이도류", "세오이 나게(업어치기)", "오사에코미"], "answer": "세오이 나게(업어치기)"},
        {"question": "크리켓에서 투수 역할을 하는 선수는?", "options": ["배터", "볼러", "위켓키퍼", "필더"], "answer": "볼러"},
        {"question": "바둑과 유사하지만 흑과 백 돌 대신 색돌을 사용하며 5목을 맞추는 게임은?", "options": ["바둑", "장기", "오델로", "오목"], "answer": "오목"},
        {"question": "탁구에서 한 세트를 끝내려면 몇 점을 먼저 얻어야 하나요?", "options": ["9점", "11점", "15점", "21점"], "answer": "11점"},
        {"question": "스케이트보드 경기에서 720도 회전 후 착지하는 기술 이름은?", "options": ["올리", "킥플립", "540", "720"], "answer": "720"},
        {"question": "수영에서 접영을 할 때 발차기 방식은?", "options": ["돌핀 킥", "프로펠러 킥", "개구리 킥", "플러터 킥"], "answer": "돌핀 킥"},
        {"question": "프로야구에서 투수가 타자를 삼진 아웃 시킬 때 필요한 스트라이크 횟수는?", "options": ["2회", "3회", "4회", "5회"], "answer": "3회"},
        {"question": "체스에서 가장 강력한 기물은?", "options": ["킹", "퀸", "룩", "비숍"], "answer": "퀸"},
        {"question": "아이스하키 경기의 한 피리어드는 몇 분인가요?", "options": ["15분", "20분", "25분", "30분"], "answer": "20분"},
        {"question": "야구에서 타자가 세 번 연속 타석에서 무출루를 기록하면 무엇이라고 부르나요?", "options": ["연속 안타", "삼진 루", "삼연속 삼진", "삼타자 삼진"], "answer": "삼연속 삼진"},
        {"question": "올림픽에서 수영 및 자전거, 달리기를 모두 포함하는 경기는?", "options": ["마라톤", "철인 3종 경기", "10종 경기", "펜싱"], "answer": "철인 3종 경기"},
        {"question": "세계 4대 마라톤 대회가 아닌 것은?", "options": ["보스턴 마라톤", "런던 마라톤", "뉴욕 마라톤", "도쿄 마라톤"], "answer": "도쿄 마라톤"},
        {"question": "배드민턴에서 서브가 대각선으로 넘어가야 하는 구역을 무엇이라 합니까?", "options": ["서비스 영역", "코트", "더블", "서비스 박스"], "answer": "서비스 박스"},
        {"question": "롤링 스톤이 발표하는 '세계 최고의 권투 선수'로 자주 언급되는 무하마드 알리의 본명은?", "options": ["캐시어스 클레이", "마이크 타이슨", "조 프레이저", "조지 포먼"], "answer": "캐시어스 클레이"},
        {"question": "테니스에서 한 경기의 포인트 진행 순서는?", "options": ["0-15-30-40-게임", "0-10-20-30-게임", "0-25-50-75-게임", "0-5-10-15-게임"], "answer": "0-15-30-40-게임"},
        {"question": "축구에서 '펠레'가 출전했던 월드컵 횟수는?", "options": ["2번", "3번", "4번", "5번"], "answer": "4번"},
        {"question": "도쿄 올림픽을 1년 연기한 이유는?", "options": ["자연 재해", "전쟁", "COVID-19 팬데믹", "정치적 갈등"], "answer": "COVID-19 팬데믹"},
        {"question": "e스포츠 리그 of Legends의 국제 대회 '월드 챔피언십'의 약칭은?", "options": ["MSI", "WCS", "Worlds", "Invitational"], "answer": "Worlds"},
        {"question": "한국 프로야구에서 '다승왕'은 어떤 기록에 주어지는 타이틀입니까?", "options": ["홈런 1위", "승리 투수 수 1위", "도루 1위", "안타 1위"], "answer": "승리 투수 수 1위"},
        {"question": "야구에서 '노히트 노런'이 의미하는 것은?", "options": ["볼넷 없음", "안타와 득점 모두 허용 안함", "무실책 경기", "투수가 삼진 20개"], "answer": "안타와 득점 모두 허용 안함"},
        {"question": "중거리 달리기 경기 1500m에서 세계 기록을 보유한 선수는?", "options": ["하세릴라시", "엘 게루즈", "마이클 존슨", "우사인 볼트"], "answer": "엘 게루즈"},
        {"question": "농구에서 '트리플 더블'은 어떤 기록을 의미합니까?", "options": ["3점슛 10개 이상", "득점/리바운드/어시스트가 두 자릿수", "3쿼터 연속 득점", "반칙 3회"], "answer": "득점/리바운드/어시스트가 두 자릿수"},
        {"question": "배구에서 블로킹 시 손가락을 벌리고 사용하는 기술은?", "options": ["페이크", "톱스핀", "더블 블로킹", "스프레드 블록"], "answer": "스프레드 블록"},
        {"question": "다트 게임에서 중앙 빨간 부분의 점수는?", "options": ["25점", "50점", "75점", "100점"], "answer": "50점"},
        {"question": "아이스하키 선수는 몇 명으로 구성된 팀이 경기에 출전합니까? (골리 포함)", "options": ["5명", "6명", "7명", "8명"], "answer": "6명"},
        {"question": "철인 3종 경기의 순서가 올바른 것은?", "options": ["수영-사이클-달리기", "달리기-수영-사이클", "사이클-수영-달리기", "수영-달리기-사이클"], "answer": "수영-사이클-달리기"},
        {"question": "우리가 알고 있는 수영 영법이 아닌 것은?", "options": ["자유형", "평영", "배영", "상어형"], "answer": "상어형"},
        {"question": "소프트볼은 어떤 스포츠에서 파생된 경기입니까?", "options": ["배구", "야구", "농구", "하키"], "answer": "야구"},
        {"question": "경마에서 기수가 타는 말의 나이는 기준으로 몇 살부터 경주에 출전할 수 있나요?", "options": ["1세", "2세", "3세", "4세"], "answer": "2세"},
        {"question": "월드컵 본선에 처음 출전한 한국 축구 국가대표팀은 어느 해입니까?", "options": ["1954년", "1962년", "1986년", "2002년"], "answer": "1954년"},
        {"question": "농구 NBA의 시즌 MVP를 가장 많이 수상한 선수는?", "options": ["마이클 조던", "카림 압둘-자바", "르브론 제임스", "매직 존슨"], "answer": "카림 압둘-자바"},
    ],
    "웹툰": [
        {"question": "'이태원 클라쓰'의 원작 웹툰은 어디에서 연재되었나요?", "options": ["카카오페이지", "레진코믹스", "네이버 웹툰", "다음 웹툰"], "answer": "다음 웹툰"},
        {"question": "웹툰 '신과 함께'는 몇 개의 부(장)로 구성되어 있습니까?", "options": ["1부", "2부", "3부", "4부"], "answer": "3부"},
        {"question": "웹툰 '패션왕'의 주인공 이름은?", "options": ["우기명", "유정", "짱구", "강호"], "answer": "우기명"},
        {"question": "웹툰 '기기괴괴'는 어떤 장르로 분류됩니까?", "options": ["공포", "코미디", "판타지", "스포츠"], "answer": "공포"},
        {"question": "웹툰 '귀곡의 문'과 '삼봉이발소'의 공통된 작가는?", "options": ["주호민", "강풀", "조석", "미티"], "answer": "강풀"},
        {"question": "웹툰 '조의 영역'을 연재한 플랫폼은?", "options": ["네이버 웹툰", "다음 웹툰", "탑툰", "레진코믹스"], "answer": "네이버 웹툰"},
        {"question": "웹툰 '먹이'의 주된 소재는?", "options": ["좀비", "뱀파이어", "늑대인간", "식물"], "answer": "좀비"},
        {"question": "웹툰 '더 복서'에서 주인공의 별명은?", "options": ["겸둥이", "괴물", "천재", "루저"], "answer": "괴물"},
        {"question": "웹툰 '복학왕'의 작가 필명은?", "options": ["기안84", "박태준", "주호민", "김풍"], "answer": "기안84"},
        {"question": "웹툰 '마음의 소리'에서 조석의 동생 이름은?", "options": ["조권", "조준", "조나단", "조석2"], "answer": "조준"},
        {"question": "웹툰 '지금 우리 학교는'의 영어 제목은?", "options": ["All of Us Are Dead", "Sweet Home", "Strangers from Hell", "Sky Castle"], "answer": "All of Us Are Dead"},
        {"question": "웹툰 '여신강림'의 주인공이 사용하는 메이크업 플랫폼은?", "options": ["유튜브", "인스타그램", "블로그", "카카오TV"], "answer": "유튜브"},
        {"question": "웹툰 '노블레스'의 작가 콤비는 'SON Jae Ho'와 누구인가요?", "options": ["Lee Gwang Su", "Kim Jung Hoon", "Park Hae Jin", "Jin Suho"], "answer": "Lee Gwang Su"},
        {"question": "웹툰 '가우스전자'의 배경은 어떤 회사입니까?", "options": ["대기업 가전회사", "자동차 회사", "통신 회사", "게임 회사"], "answer": "대기업 가전회사"},
        {"question": "웹툰 '낢이 사는 이야기'는 어떤 형식으로 구성되어 있습니까?", "options": ["일상 에세이", "SF 판타지", "스릴러", "스포츠"], "answer": "일상 에세이"},
        {"question": "웹툰 '또 다른 세계'의 영어 제목은?", "options": ["Another World", "Parallel Universe", "Other Life", "Different Dimension"], "answer": "Another World"},
        {"question": "웹툰 '슈퍼시크'의 주인공 직업은?", "options": ["연예인", "회사원", "작가", "프리랜서"], "answer": "프리랜서"},
        {"question": "웹툰 '유리가면'은 어떤 장르로 분류됩니까?", "options": ["로맨스", "공포", "판타지", "개그"], "answer": "로맨스"},
        {"question": "웹툰 '호텔 델루나'의 원작 웹툰 제목은?", "options": ["호텔 델루나", "월령", "호텔 블루문", "라구나"], "answer": "호텔 델루나"},
        {"question": "웹툰 '프리드로우'의 주인공이 가지고 있는 특별한 능력은?", "options": ["시간을 멈춤", "심령술", "미술 능력", "운동신경"], "answer": "운동신경"},
        {"question": "웹툰 '이런 영웅은 싫어'의 작가 이름은?", "options": ["삼촌", "삼중", "삼촌팬", "손희"], "answer": "삼촌"},
        {"question": "웹툰 '닥터 프로스트'의 주인공 직업은?", "options": ["정신과 의사", "외과 의사", "변호사", "경찰"], "answer": "정신과 의사"},
        {"question": "웹툰 '치악산'은 어떤 장르인가요?", "options": ["공포", "코미디", "로맨스", "스포츠"], "answer": "공포"},
        {"question": "웹툰 '툰드라쇼'의 주요 형식은?", "options": ["4컷 만화", "장편 스토리", "실사", "소설"], "answer": "4컷 만화"},
        {"question": "웹툰 '호랑이형님'은 어느 시대를 배경으로 합니까?", "options": ["현대", "고려 시대", "조선 시대", "중국 삼국 시대"], "answer": "고려 시대"},
        {"question": "웹툰 '냄새를 보는 소녀'는 어떤 능력을 가진 주인공 이야기입니까?", "options": ["냄새를 시각화", "미래를 예측", "사람의 마음을 읽음", "동물과 소통"], "answer": "냄새를 시각화"},
        {"question": "웹툰 '와라! 편의점'은 어떤 공간을 배경으로 합니까?", "options": ["카페", "편의점", "학교", "병원"], "answer": "편의점"},
        {"question": "웹툰 '리턴 투 플레이어'는 어떤 장르인가요?", "options": ["게임 판타지", "로맨스", "스포츠", "공포"], "answer": "게임 판타지"},
        {"question": "웹툰 '남주의 첫날밤을 가져버렸다'는 어떤 플랫폼에서 인기를 끌었습니까?", "options": ["카카오페이지", "레진코믹스", "네이버 웹툰", "다음 웹툰"], "answer": "카카오페이지"},
        {"question": "웹툰 '낙원의 이론'의 작가는?", "options": ["미티", "해니한", "이원식", "변필삭"], "answer": "미티"},
        {"question": "웹툰 '모기전쟁'의 주제는?", "options": ["흡혈귀", "모기 박멸", "좀비", "외계인"], "answer": "모기 박멸"},
        {"question": "웹툰 '세기말 풋사과 보습학원'은 어떤 장르입니까?", "options": ["개그", "로맨스", "액션", "호러"], "answer": "개그"},
        {"question": "웹툰 '비질란테'의 주인공이 저지르는 것은?", "options": ["음악 활동", "법을 벗어난 처벌", "요리 경연", "스포츠 중계"], "answer": "법을 벗어난 처벌"},
        {"question": "웹툰 '나빌레라'는 어떤 취미를 다루고 있습니까?", "options": ["발레", "그림", "요리", "음악"], "answer": "발레"},
        {"question": "웹툰 '럭키짱'의 주인공 이름은?", "options": ["나도현", "박준호", "김건모", "황민"], "answer": "나도현"},
        {"question": "웹툰 '짝사랑의 정도'의 작가는?", "options": ["심윤수", "기안84", "강풀", "채색남"], "answer": "심윤수"},
        {"question": "웹툰 '힙합'을 소재로 한 작품은?", "options": ["힙합신", "쇼미더툰", "리듬게임", "언터쳐블"], "answer": "쇼미더툰"},
        {"question": "웹툰 '바른연애 길잡이'는 어떤 장르인가요?", "options": ["연애 로맨스", "액션", "공포", "SF"], "answer": "연애 로맨스"},
        {"question": "웹툰 '유쾌한 왕따'에서 주인공이 겪는 문제는?", "options": ["왕따", "시험 스트레스", "연애 문제", "가족 갈등"], "answer": "왕따"},
        {"question": "웹툰 '마음의 온도'의 핵심 소재는?", "options": ["사랑", "요리", "음악", "천문학"], "answer": "사랑"},
    ],
}

# Extend the original quiz lists with the additional questions
for _cat, _qs in more_questions.items():
    if _cat in quizzes:
        quizzes[_cat].extend(_qs)

# In-memory storage for users and posts. In a real application these would be persistent.
users = {}  # username: {"password": str, "nickname": str, "badges": {category: badge}}
# Each post is represented as a dictionary with title, content, author, reaction counts, optional media, and timestamp
posts = {category: [] for category in quizzes.keys()}  # category: list of posts per category

# Define badge ranking for upgrade logic
BADGE_RANK = {"입문": 1, "중수": 2, "고인물": 3}


def get_badge(score: int, total: int) -> str:
    """Return badge name based on quiz score."""
    percentage = (score / total) * 100
    if percentage >= 80:
        return "고인물"
    elif percentage >= 50:
        return "중수"
    else:
        return "입문"


# Inject global variables into all templates: login status, user badges, and category list.
@app.context_processor
def inject_globals():
    logged_in = "username" in session
    user_badges = {}
    if logged_in:
        user = users.get(session["username"])
        if user:
            user_badges = user.get("badges", {})
    categories = list(quizzes.keys())
    return dict(logged_in=logged_in, user_badges=user_badges, categories=categories)


@app.route("/")
def index():
    """
    Display the home page showing aggregated posts from all categories.
    This page is accessible to everyone without requiring login. Users who are
    logged in will see their badge information reflected in the ability to
    click into individual posts (only if they have the badge for that
    category). Non‑authenticated visitors can browse the list but cannot
    access individual post details.
    """
    # Determine login status and badges for the current user (if any)
    logged_in = "username" in session
    username = session.get("username")
    user_badges = users[username]["badges"] if logged_in else {}

    now = datetime.now()
    week_ago = now - timedelta(days=7)
    aggregated_posts = []
    hot_posts_list = []
    # Collect posts from all categories
    for cat, post_list in posts.items():
        for idx, post in enumerate(post_list):
            author = post.get("user")
            author_info = users.get(author, {})
            author_badge = author_info.get("badges", {}).get(cat)
            author_nickname = author_info.get("nickname", author)
            display = {
                "category": cat,
                "index": idx,
                "title": post.get("title") if post.get("title") else (post.get("content", "무제")[:20] + ("..." if len(post.get("content", "")) > 20 else "")),
                "nickname": author_nickname,
                "badge": author_badge,
                "likes": post.get("likes", 0),
                "dislikes": post.get("dislikes", 0),
                "created_at": post.get("created_at"),
                # Determine if the current user can access this post
                # Users with any badge can access all boards. Non-authenticated users cannot.
                "can_access": logged_in and (len(user_badges) > 0),
            }
            aggregated_posts.append(display)
            # Identify hot posts within the last week
            created_at = post.get("created_at")
            if created_at and created_at >= week_ago:
                hot_posts_list.append(display)
    # Sort aggregated posts by created_at descending (fallback to now)
    aggregated_posts_sorted = sorted(aggregated_posts, key=lambda p: p["created_at"] or now, reverse=True)
    # Determine hot posts across all categories (top 5 by likes)
    hot_posts_sorted = sorted(hot_posts_list, key=lambda p: p["likes"], reverse=True)[:5]
    return render_template(
        "home.html",
        posts=aggregated_posts_sorted,
        hot_posts=hot_posts_sorted,
        categories=list(quizzes.keys()),
        logged_in=logged_in,
        user_badges=user_badges,
    )


@app.route("/signup", methods=["GET", "POST"])
def signup():
    """Handle user registration."""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        nickname = request.form.get("nickname", "").strip()
        # Validate inputs
        if not username or not password or not nickname:
            flash("아이디, 비밀번호, 닉네임을 모두 입력해주세요.")
            return redirect(url_for("signup"))
        if username in users:
            flash("이미 존재하는 아이디입니다.")
            return redirect(url_for("signup"))
        # Optionally ensure nickname uniqueness (not enforced here)
        users[username] = {"password": password, "nickname": nickname, "badges": {}}
        flash("회원가입이 완료되었습니다. 로그인해주세요.")
        return redirect(url_for("login"))
    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Handle user login."""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        user = users.get(username)
        if user and user["password"] == password:
            session["username"] = username
            flash("로그인되었습니다.")
            return redirect(url_for("select_category"))
        flash("아이디 또는 비밀번호가 올바르지 않습니다.")
        return redirect(url_for("login"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    """Log the user out by clearing the session."""
    session.clear()
    flash("로그아웃되었습니다.")
    return redirect(url_for("login"))


@app.route("/select", methods=["GET", "POST"])
def select_category():
    """Allow logged-in users to choose a category for the quiz/board."""
    if "username" not in session:
        flash("로그인이 필요합니다.")
        return redirect(url_for("login"))
    username = session["username"]
    if request.method == "POST":
        # Always allow starting a quiz for the selected category, even if the user has a badge.
        category = request.form.get("category")
        if category in quizzes:
            # Always draw a limited number of random questions for the quiz
            # Limit the number of questions per attempt to 5.  If fewer questions exist
            # for a category, take all of them.
            total_questions = len(quizzes[category])
            num_questions = min(5, total_questions)
            questions = sample(quizzes[category], num_questions)
            session["quiz_category"] = category
            session["quiz_questions"] = questions
            return redirect(url_for("take_quiz", category=category))
        else:
            flash("잘못된 분야입니다.")
            return redirect(url_for("select_category"))
    # Determine which categories user already has access to
    badges = users[username]["badges"]
    return render_template(
        "select.html",
        categories=list(quizzes.keys()),
        badges=badges,
    )


@app.route("/quiz/<category>", methods=["GET", "POST"])
def take_quiz(category):
    """Display the quiz and handle answer submission."""
    # Ensure the user has an active quiz session for the given category
    if "username" not in session or session.get("quiz_category") != category:
        flash("올바른 퀴즈 세션이 아닙니다.")
        return redirect(url_for("select_category"))
    if request.method == "POST":
        # Evaluate quiz answers submitted by the user
        questions = session.get("quiz_questions", [])
        score = 0
        for i, q in enumerate(questions):
            user_answer = request.form.get(f"q{i}")
            if user_answer == q.get("answer"):
                score += 1
        badge = get_badge(score, len(questions))
        username = session["username"]
        # Only update badge if the new badge rank is higher than existing
        current_badge = users[username]["badges"].get(category)
        if current_badge is None or BADGE_RANK.get(badge, 0) > BADGE_RANK.get(current_badge, 0):
            users[username]["badges"][category] = badge
        # Clear quiz session variables
        session.pop("quiz_category", None)
        session.pop("quiz_questions", None)
        return render_template(
            "quiz_result.html",
            category=category,
            score=score,
            total=len(questions),
            badge=badge,
        )
    # For GET requests, prepare enumerated questions for Jinja2 compatibility
    questions = session.get("quiz_questions", [])
    # Create a list of tuples (index, question_dict) to avoid using loop.parent in Jinja2
    enumerated_questions = list(enumerate(questions))
    return render_template(
        "quiz.html",
        category=category,
        questions=enumerated_questions,
    )


@app.route("/board/<category>", methods=["GET", "POST"])
def board(category: str):
    """
    Display the discussion board for a category. Unlike the original implementation,
    non‑logged‑in users can view the list of posts and hot posts, but only users
    who are logged in and have passed the quiz for the category can create posts
    or interact with posts (vote, like/dislike, etc.).
    """
    # Determine if the current session is logged in
    logged_in = "username" in session
    username = session.get("username")
    # Determine user badges if logged in, else empty dict
    user_badges = users[username]["badges"] if logged_in else {}
    # Whether the user has access to this board
    # Users with any badge may view and interact across all boards
    can_access = logged_in and (len(user_badges) > 0)
    if request.method == "POST":
        # Only allow voting (like/dislike) if the user is logged in and has access
        vote_index = request.form.get("vote_index")
        vote_type = request.form.get("vote_type")
        if not can_access:
            flash("로그인한 후 해당 분야 뱃지를 보유한 사용자만 추천/비추천을 할 수 있습니다.")
            return redirect(url_for("board", category=category))
        if vote_index is not None and vote_type in {"like", "dislike"}:
            try:
                idx = int(vote_index)
                if 0 <= idx < len(posts.get(category, [])):
                    if vote_type == "like":
                        posts[category][idx]["likes"] += 1
                        flash("추천했습니다.")
                    else:
                        posts[category][idx]["dislikes"] += 1
                        flash("비추천했습니다.")
            except (ValueError, KeyError):
                pass
        return redirect(url_for("board", category=category))
    # Prepare data for GET: compute hot posts and regular posts
    # Determine the user's badge for display; only set if they have access
    # Determine the user's badge for this specific category (if any) for display
    current_badge = user_badges.get(category) if logged_in else None
    # List of all categories for navigation (board list pages are viewable by anyone)
    all_categories = list(quizzes.keys())
    # Convert posts to display-friendly dicts with author badge and nickname and index
    now = datetime.now()
    week_ago = now - timedelta(days=7)
    display_posts: list[dict] = []
    hot_posts_list: list[dict] = []
    for idx, post in enumerate(posts.get(category, [])):
        author = post.get("user")
        author_info = users.get(author, {})
        author_badge = author_info.get("badges", {}).get(category)
        author_nickname = author_info.get("nickname", author)
        display = {
            "index": idx,
            "title": post.get("title") if post.get("title") else (post.get("content", "무제")[:20] + ("..." if len(post.get("content", "")) > 20 else "")),
            "username": author,
            "nickname": author_nickname,
            "badge": author_badge,
            "likes": post.get("likes", 0),
            "dislikes": post.get("dislikes", 0),
            "created_at": post.get("created_at"),
        }
        display_posts.append(display)
        # Identify posts within the last week for the hot posts list
        created_at = post.get("created_at")
        if created_at and created_at >= week_ago:
            hot_posts_list.append(display)
    # Sort hot posts by likes descending and take top 3
    hot_posts_sorted = sorted(hot_posts_list, key=lambda p: p["likes"], reverse=True)
    hot_posts_display = hot_posts_sorted[:3]
    # Sort regular posts by created_at descending (fallback to now if missing)
    regular_posts = sorted(display_posts, key=lambda p: p["created_at"] or now, reverse=True)
    return render_template(
        "board.html",
        category=category,
        badge=current_badge,
        posts=regular_posts,
        hot_posts=hot_posts_display,
        write_url=url_for("new_post", category=category),
        categories=all_categories,
        user_badges=user_badges,
        logged_in=logged_in,
        can_access=can_access,
    )


@app.route("/post/<category>/<int:idx>")
def view_post(category: str, idx: int):
    """
    Display a single post with its content, media and reactions. Only users who
    are logged in and have the appropriate badge for the category may view
    individual posts. Non‑authenticated visitors will be redirected to the login
    page with a message, and users without the badge will be asked to take
    the quiz first.
    """
    # Validate category and index existence
    if category not in posts or idx < 0 or idx >= len(posts[category]):
        abort(404)
    # Require login before viewing posts
    if "username" not in session:
        flash("로그인 후 게시글을 볼 수 있습니다.")
        return redirect(url_for("login"))
    username = session["username"]
    # Check that the user has at least one badge; if not, they must take a quiz first
    user_badges = users[username].get("badges", {})
    if not user_badges:
        flash("게시글을 보기 위해서는 최소 하나의 퀴즈를 통과해야 합니다.")
        return redirect(url_for("select_category"))
    post = posts[category][idx]
    # Prepare author display information
    author = post.get("user")
    author_info = users.get(author, {})
    author_nickname = author_info.get("nickname", author)
    author_badge = author_info.get("badges", {}).get(category)
    return render_template(
        "post.html",
        category=category,
        idx=idx,
        post=post,
        author_nickname=author_nickname,
        author_badge=author_badge,
    )


@app.route("/post/<category>/<int:idx>/vote/<vote_type>", methods=["POST"])
def vote_post(category: str, idx: int, vote_type: str):
    """Handle like/dislike votes from the post detail page."""
    if category not in posts or idx < 0 or idx >= len(posts[category]):
        abort(404)
    if vote_type not in {"like", "dislike"}:
        abort(400)
    post = posts[category][idx]
    # Update counts
    if vote_type == "like":
        post["likes"] += 1
        flash("추천했습니다.")
    else:
        post["dislikes"] += 1
        flash("비추천했습니다.")
    return redirect(url_for("view_post", category=category, idx=idx))


@app.route("/board/<category>/new", methods=["GET", "POST"])
def new_post(category: str):
    """
    Display a form to create a new post. Upon submission, save the post and redirect to the board.
    """
    # Ensure user is logged in and has access to the board
    if "username" not in session:
        flash("로그인이 필요합니다.")
        return redirect(url_for("login"))
    username = session["username"]
    user_badges = users[username].get("badges", {})
    # Require the user to have at least one badge to post on any board
    if not user_badges:
        flash("게시글을 작성하려면 먼저 퀴즈를 통과해야 합니다.")
        return redirect(url_for("select_category"))
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        file = request.files.get("media")
        media_filename = None
        if file and file.filename:
            if allowed_file(file.filename):
                filename = secure_filename(file.filename)
                unique_name = f"{username}_{len(posts[category])}_{filename}"
                save_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
                file.save(save_path)
                media_filename = unique_name
            else:
                flash("허용되지 않는 파일 형식입니다. (이미지: png, jpg, jpeg, gif / 동영상: mp4, mov, webm)")
        if title or content or media_filename:
            posts[category].append(
                {
                    "title": title if title else "무제",
                    "content": content,
                    "user": username,
                    "likes": 0,
                    "dislikes": 0,
                    "media": media_filename,
                    "created_at": datetime.now(),
                }
            )
            flash("게시글이 등록되었습니다.")
            return redirect(url_for("board", category=category))
        flash("제목이나 내용을 입력하거나 미디어를 첨부해야 합니다.")
    return render_template("new_post.html", category=category)


if __name__ == "__main__":
    # Run the Flask development server. In a real deployment, use a WSGI server.
    app.run(debug=True, host="0.0.0.0")